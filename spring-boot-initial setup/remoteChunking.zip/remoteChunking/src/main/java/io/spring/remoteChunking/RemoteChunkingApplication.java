package io.spring.remoteChunking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemoteChunkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemoteChunkingApplication.class, args);
	}

}
