package io.spring.retry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetryApplicationTests {

	@Test
	void contextLoads() {
	}

}
