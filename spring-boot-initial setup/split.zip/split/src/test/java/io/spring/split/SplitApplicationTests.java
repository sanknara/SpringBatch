package io.spring.split;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SplitApplicationTests {

	@Test
	void contextLoads() {
	}

}
