package io.spring.localPartioning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalPartioningApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalPartioningApplication.class, args);
	}

}
