package io.spring.itemProcessorInterface;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemProcessorInterfaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
