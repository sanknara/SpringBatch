package io.spring.decision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecisionApplication.class, args);
	}

}
