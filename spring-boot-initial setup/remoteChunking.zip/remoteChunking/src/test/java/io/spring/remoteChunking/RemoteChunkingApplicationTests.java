package io.spring.remoteChunking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemoteChunkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
