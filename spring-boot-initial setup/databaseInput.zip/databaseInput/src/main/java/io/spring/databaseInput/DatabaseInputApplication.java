package io.spring.databaseInput;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseInputApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseInputApplication.class, args);
	}

}
