package io.spring.xmlFileOutput;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlFileOutputApplicationTests {

	@Test
	void contextLoads() {
	}

}
