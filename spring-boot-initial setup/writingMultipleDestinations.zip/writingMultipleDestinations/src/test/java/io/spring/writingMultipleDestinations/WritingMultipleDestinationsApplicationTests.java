package io.spring.writingMultipleDestinations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WritingMultipleDestinationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
