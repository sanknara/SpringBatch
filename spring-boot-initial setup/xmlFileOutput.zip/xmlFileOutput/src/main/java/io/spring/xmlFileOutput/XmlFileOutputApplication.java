package io.spring.xmlFileOutput;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlFileOutputApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlFileOutputApplication.class, args);
	}

}
