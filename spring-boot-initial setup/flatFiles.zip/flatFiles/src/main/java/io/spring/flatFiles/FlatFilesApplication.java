package io.spring.flatFiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlatFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlatFilesApplication.class, args);
	}

}
