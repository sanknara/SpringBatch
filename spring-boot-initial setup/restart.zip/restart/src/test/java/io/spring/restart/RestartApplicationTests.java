package io.spring.restart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestartApplicationTests {

	@Test
	void contextLoads() {
	}

}
