package io.spring.asyncItemProcessorItemWriter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsyncItemProcessorItemWriterApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsyncItemProcessorItemWriterApplication.class, args);
	}

}
