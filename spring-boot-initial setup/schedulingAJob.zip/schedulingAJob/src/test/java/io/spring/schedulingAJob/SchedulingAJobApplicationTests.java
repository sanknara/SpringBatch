package io.spring.schedulingAJob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingAJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
