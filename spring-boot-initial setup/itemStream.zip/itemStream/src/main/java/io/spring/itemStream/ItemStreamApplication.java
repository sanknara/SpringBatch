package io.spring.itemStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemStreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemStreamApplication.class, args);
	}

}
