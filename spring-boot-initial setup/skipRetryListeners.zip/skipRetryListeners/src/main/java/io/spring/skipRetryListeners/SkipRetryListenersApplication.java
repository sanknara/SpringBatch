package io.spring.skipRetryListeners;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkipRetryListenersApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkipRetryListenersApplication.class, args);
	}

}
