package io.spring.databaseOutput;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseOutputApplicationTests {

	@Test
	void contextLoads() {
	}

}
