package io.spring.writingMultipleDestinations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WritingMultipleDestinationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WritingMultipleDestinationsApplication.class, args);
	}

}
