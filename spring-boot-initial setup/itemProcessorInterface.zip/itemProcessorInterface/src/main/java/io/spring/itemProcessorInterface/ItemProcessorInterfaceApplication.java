package io.spring.itemProcessorInterface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemProcessorInterfaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemProcessorInterfaceApplication.class, args);
	}

}
