package io.spring.transitions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransitionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransitionsApplication.class, args);
	}

}
