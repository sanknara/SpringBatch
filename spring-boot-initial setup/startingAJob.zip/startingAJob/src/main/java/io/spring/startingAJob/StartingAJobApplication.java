package io.spring.startingAJob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartingAJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartingAJobApplication.class, args);
	}

}
