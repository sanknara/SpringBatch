package io.spring.nestedJobs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NestedJobsApplicationTests {

	@Test
	void contextLoads() {
	}

}
