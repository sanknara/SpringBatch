package io.spring.multithreadedStep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultithreadedStepApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultithreadedStepApplication.class, args);
	}

}
