package io.spring.InputInterfaces;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InputInterfacesApplication {

	public static void main(String[] args) {
		SpringApplication.run(InputInterfacesApplication.class, args);
	}

}
